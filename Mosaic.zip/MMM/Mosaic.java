/* Diya Patel
Object Oriented Programming
Sprint 4 - Mosaic
*/
public class Mosaic{

    public static void main(String [] args){

        TileFrame frame = new TileFrame();
        frame.setVisible(true);   

        //TilePanel panel = new TilePanel();
        //frame.add(panel);
        frame.setLocationRelativeTo(null);
          
        System.out.print("Start Paint...");
        
}

}
