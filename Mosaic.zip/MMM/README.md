# Mosaic-Sprint4
### Diya Patel
### Email: diyapatel@lewisu.edu

#### GUI Application: Mosaic 

This appplication creates a colorful pattern of shapes and letters. It includes randomly colored circles and squares with centered randomly colored letters in the center of each shape. No matter what color the shape is, the color of the letter makes the letter visible.

Sample Output: <img width="609" alt="Screen Shot 2021-03-12 at 12 34 22 PM" src="https://user-images.githubusercontent.com/78065221/110983410-55bbba80-832f-11eb-86b1-54623af9da92.png">


Installation: There are three files needed to open this GUI Application. 
              1) TileFrame.java 
              2) TilePanel.java
              3) Mosaic.java (Main)

For Licence: This project is licensed under MIT License. Please Licence file for more details


